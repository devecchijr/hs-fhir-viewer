'use strict';

const express = require('express');
const path = require('path');
const http = require('http');
const https = require('https');
const cors = require('cors');
const fs = require('fs');
const bodyParser = require('body-parser');
const proxy = require('http-proxy-middleware');
const axios = require('axios');

let server = express();

var sslOptions = {
  key: fs.readFileSync('../cert/key.pem'),
  cert: fs.readFileSync('../cert/cert.pem'),
  passphrase: 'isbdemo'
};

let httpServer = http.createServer(server);
let httpsServer = https.createServer(sslOptions, server);

server.use(cors())
server.use(bodyParser.json());
server.use(bodyParser.urlencoded({ extended: false }));

var port = process.env.PORT || 3000;
console.log(path.join(__dirname, 'app'));
server.use(express.static(path.join(__dirname, '../app')));

// Render your site
const renderIndex = (req, res) => {
  res.sendFile(path.resolve(__dirname, '../app/index.html'));
}

server.use('/csp', proxy({target: 'http://localhost:57772', changeOrigin: true}));

server.get('/*', renderIndex);

httpServer.listen(3000, () => {
  console.log('Listening on: http://localhost:3000');
});